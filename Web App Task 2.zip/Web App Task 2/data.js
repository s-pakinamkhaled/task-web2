module.exports = {
    books: [
        { id: 1, title: 'Nothing', authorId: 1, available: true },
        { id: 2, title: 'Consistency', authorId: 2, available: true },
        { id: 3, title: 'World War 2', authorId: 3, available: true }
    ],
    authors: [
        { id: 1, name: 'H.Ashraf' },
        { id: 2, name: 'Fares Ashraf' },
        { id: 3, name: 'Zain Ashraf' }
    ],
    users: [
        { id: 1, name: 'Hesham Ashraf' },
        { id: 2, name: 'Pakinam Khaled' }
    ]
};
